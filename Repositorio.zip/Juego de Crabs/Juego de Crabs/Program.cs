﻿using System;
using Juego_de_Crabs;

Console.WriteLine("Bienvenido al juego de Crabs! \n");

    Craps juego = new Craps();
    juego.Jugar();