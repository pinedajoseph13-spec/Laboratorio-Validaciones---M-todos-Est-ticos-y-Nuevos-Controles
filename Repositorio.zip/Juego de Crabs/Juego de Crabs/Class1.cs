﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Juego_de_Crabs;
public class Craps
{
    private Random numerosAleatorios = new Random();

    private enum NombreDados
    {
        DOS_UNO = 2,
        TRES = 3,
        SIETE = 7,
        ONCE = 11, 
        DOCE = 12
    }
    private enum Estado
    {
        CONTINUA, 
        GANA, 
        PIERDE
    }
    public void Jugar()
    {
        Estado estadojuego = Estado.CONTINUA;
        int miPunto = 0;
        int SumaDeDados = LanzarDados();

        switch ((NombreDados)SumaDeDados)
        {
            case NombreDados.SIETE:
            case NombreDados.ONCE:

                estadojuego = Estado.GANA;
                break;

            case NombreDados.DOS_UNO:
            case NombreDados.TRES:
            case NombreDados.DOCE:
                estadojuego = Estado.PIERDE;
                break;

            default:
                estadojuego = Estado.CONTINUA;
                miPunto = SumaDeDados;
                Console.WriteLine($"El punto es: {miPunto}");
                break;
        }
        while (estadojuego == Estado.CONTINUA)
        {
            SumaDeDados = LanzarDados();

            if(SumaDeDados == miPunto)
            {
                estadojuego = Estado.GANA;

            }
            else if (SumaDeDados == (int)NombreDados.SIETE)
            {
                estadojuego = Estado.PIERDE;
            }
                
        }
        
        if (estadojuego == Estado.GANA)
        {
            Console.WriteLine("El jugador Gana");
        }
        else
        {
            Console.WriteLine("El jugador pierde");
        }
    }

    public int LanzarDados()
    {
        int Dado1 = numerosAleatorios.Next(1, 7);
        int Dado2 = numerosAleatorios.Next(1, 7);

        int suma = Dado1 + Dado2;

        Console.WriteLine($"El jugador lazo los dados {Dado1} + {Dado2} y su suma es: {suma}");

        return suma;
    }
}