﻿using System;
using System.Text.RegularExpressions;
    
namespace Ejemplo2FormualarioGrid
{
    public class Utilidades
    {
        public static bool EsCorreoValido(string correo)
        {
            if (EstaEnBlanco(correo))
            {
                return false;
            }
            string patron = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
            return Regex.IsMatch(correo, patron);

        }

        public static bool EstaEnBlanco(string texto)
        {
            return string.IsNullOrWhiteSpace(texto);

        }
    }
}
